# Milestone Feedback and Handoff Protocol

## 1. Status and scope

**Status.** This protocol is the canonical package contract for framework slots M1-M5, feedback, adjudication, approval, lineage, reopening, and handoff evidence. Assigned milestone meanings come from the controlling brief through `ASSIGNMENT_MILESTONE_PROCESS.md`; the terminal M5 slot may represent a final paper that the assignment does not itself call a fifth milestone.

**Scope.** The protocol governs project-level lifecycle records stored under `reviews/phase_state.json.milestone_framework`. It does not replace the section-level Lifecycle-Phase Ladder in `PHASE_PROTOCOL.md`. `reviews/phase_state.json` remains the only lifecycle state authority; no milestone ledger, generated Markdown file, F9 packet, plan, report, or checklist may become a second state authority.

Grounding, provenance integrity, and root filesystem-integrity rules are non-overridable. The Planner is the sole lifecycle-state writer and must use the atomic-write and concurrent-change checks already required for `reviews/phase_state.json`. Validators, renderers, the Evaluator, the Generator, and the Reflector are read-only with respect to milestone state.

## 2. Orthogonal milestone and phase axes

Milestones and phases are orthogonal. Assignment-derived milestones name project deliverables and accepted handoffs. Phases name the revision/readiness state of the active artifact or sections. For the four-milestone course-essay profile, M1-M3 normally execute within Ph1, M4 begins with its complete initial assembly in Ph1 and then spans Ph2-Ph3 review and convergence, and the separate final paper occupies the terminal M5 framework slot at Ph4. Neither vocabulary supersedes the other.

The normal coordination is:

| Milestone | Project deliverable | Normal phase binding |
|---|---|---|
| M1 | Project Memo | Ph1 |
| M2 | Annotated References | Ph1 |
| M3 | Structured Outline | Ph1 |
| M4 | Paper Draft | Ph2-Ph3 |
| M5 framework slot | Final Paper (separate from the four assigned milestones) | Ph4 |

Phase advancement never proves milestone acceptance by itself. Milestone acceptance never proves that a section satisfies a phase gate. Cross-axis gates must test both authorities without collapsing either axis.

## 3. Authority and precedence

Within the non-overridable boundaries above, milestone content and form follow this order:

1. Current user instruction.
2. Venue requirements.
3. Advisor, instructor, or committee requirements.
4. Project-local `AGENTS.md`, `directives.md`, and the declared project profile.
5. This protocol and `PHASE_PROTOCOL.md` within their respective axes.
6. General package defaults.

A higher-authority specialization may change format, add exit criteria, map a venue-named artifact to an M1-M5 semantic role, narrow scope, or authorize `not_applicable` with a reason and substitute evidence. It may not relabel a control as a deliverable, change schema meanings, fabricate or reclassify provenance, erase history, bypass Grounding or filesystem-integrity rules, or waive a blocker without an append-only authorized override.

An authorized override records the rule, scope, authority, rationale, timestamp, affected milestones and handoffs, substitute evidence when applicable, and revalidation obligations.

## 4. Milestone deliverable contracts

Each M1-M5 record requires `purpose`, `status`, `applicability`, `required_inputs`, `exit_criteria`, `artifacts`, `feedback_records`, `approval`, `handoff`, and `dependency_state`. Exactly one project-level `primary_lineage` identifies the accepted chain.

Framework mode is `native | legacy`. Applicability is `applicable | not_applicable`.

Handoff policy is a separate persistent axis. Valid `1.0.0` ledgers omit
`handoff_policy` and resolve mechanically to effective `audited` without
rewrite. Valid `1.1.0` ledgers declare exactly `handoff_policy: derived|audited`.
New native bootstrap defaults explicitly to `derived`; explicit `audited`
remains available. Existing projects change policy only through the receipted
`lab-iteration-derived-handoff-v1` migration.

Milestone status is one of:

`not_started | in_progress | feedback_pending | revision_required | accepted | reopened | superseded | not_applicable | legacy_unverified`

Approval status is `pending | approved | rejected | reopened | not_applicable`. Handoff status is `not_ready | ready | consumed | needs_revalidation | not_applicable`. Dependency state is `current | needs_revalidation | not_applicable`.

The normal contracts are:

| Milestone | Purpose | Required handoff output |
|---|---|---|
| M1 Project Memo | Explore the preliminary focus, emerging tension, questions or goals, and what draws the author to the topic; do not prematurely freeze a thesis. | M1-to-M2 packet identifying the live inquiry and source needs. |
| M2 Annotated References | Assemble relevant course readings and additional sources, explaining the contribution of each. | M2-to-M3 packet mapping the developing inquiry to source contributions and gaps. |
| M3 Structured Outline | Design the intellectual and historical context, central tension, and reciprocal analysis/application. | M3-to-M4 packet fixing section purposes, argumentative moves, sources, and open debts. |
| M4 Paper Draft | Present the complete argument for feedback at review-ready depth, while allowing provisional claims and wording. | M4-to-M5 packet binding the full draft and honestly adjudicated feedback state. |
| M5 framework slot / public FINAL | Elaborate and revise the full argument after M1-M4 and the feedback stage; publish `milestones/M5_final_paper.md` plus `submission_bundle/final_manuscript.md`; certify current manuscript identity. | Terminal packet binding explicit approval, consumed FINAL receipt/result, manuscript identity, released-export provenance, complete closure evidence, and residual risks. |

The handoff-output column describes the exact F9 representation when effective
policy is `audited`, or when `--emit-f9` explicitly requests optional evidence
under `derived`. Under effective `derived`, the default authoritative handoff
projection is `not_applicable` and milestone acceptance remains complete
without a packet.

`FINAL` is the public assignment-gate and checkpoint target; `M5` is its ledger key. The bridge is exact and one-way at the interface boundary: users and dispatch receipts say `FINAL`, while phase state and approval/checkpoint evidence say `M5`; any F9 packet does too. FINAL never aliases M4 and never rewrites accepted M4 bytes. The public close transaction follows the effective handoff policy, records the scoped FINAL publication, accepts M5, optionally writes the exact `reviews/.harness/handoffs/M5_terminal.json` evidence, and atomically sets `terminal_phase_reached` plus `terminal_round_id` only after the full terminal candidate passes.

Here, publication means the guarded project-local FINAL transaction. External
submission, upload, delivery, or dissemination is outside harness authority and
requires a separate user-authorized action.

Plans, revision plans, gates, checklists, reviews, reports, and derived views may control or evidence progress but cannot satisfy a milestone deliverable slot. Every recorded or accepted applicable deliverable also binds a qualified C6 scholarly evaluation that reuses the same consumed assignment receipt and exact Generator/Evaluator chain. The verifier replays the evaluation and its complete transitive dependency set; plausible Markdown, file presence, a clean deterministic report, or the older semantic verifier cannot substitute. M4 and M5 may use the same canonical manuscript path at different maturity depths; each accepted state binds the exact current manuscript path, SHA-256, byte count, and verification time. Changed bytes make the prior approval historical and the current binding stale.

## 5. Artifact roles and lineages

Every registered artifact has exactly one role:

`deliverable | transition_control | evidence | derived_view | export`

- `deliverable` is the project artifact the milestone exists to produce.
- `transition_control` is a plan, gate, checklist, or other control over movement.
- `evidence` records review, feedback, adjudication, approval, or validation.
- `derived_view` is reproducible human-readable output from authoritative state or evidence.
- `export` is a rendered or packaged representation of an accepted deliverable.

Every artifact also has a `lineage_id`. Multiple active candidates within a milestone require distinct lineage identifiers; filenames, directories, timestamps, and apparent similarity do not establish ancestry. `supersedes` and predecessor bindings must be explicit. Archive and live artifacts never auto-merge. Exactly one project-level `primary_lineage` may supply the accepted M1-M5 chain.

For M4 and M5, the primary-lineage `deliverable` must be a manuscript artifact. A transition control, evidence artifact, derived view, or export cannot be the sole deliverable.

## 6. Feedback provenance and adjudication

Feedback records use exactly one evidence class:

`direct_milestone_feedback | retrospective_application | harness_review_evidence | cross_cutting_guidance`

`direct_milestone_feedback` is contemporaneous attributable feedback on the named milestone. `retrospective_application` applies later feedback or principles to earlier work without rewriting that evidence as contemporaneous. `harness_review_evidence` covers Planner, Evaluator, Reflector, deterministic, or external-verifier review evidence. `cross_cutting_guidance` applies across milestones or projects.

Every record binds `feedback_id`, evidence class, source path and SHA-256, the attributable source actor and authority class, source and target milestones, receipt time, a contemporaneity-evidence path and SHA-256, lineage, blocking status, disposition, rationale, and successor effect. The source actor names the historical person or role and is not the author of a later migration event. The contemporaneity binding is the retained evidence for the receipt-time claim; unavailable legacy history stays `not captured under prior contract` rather than receiving invented metadata. Disposition is one of:

`pending | accepted | partially_accepted | rejected | deferred | informational`

Every blocking record must be adjudicated before its handoff can become ready. Direct external feedback is not mandatory at every milestone; an explicit truthful gate is mandatory. The gate may record received and adjudicated feedback, feedback not requested, unavailable history under an approved legacy boundary, or authorized non-applicability. During Ph1 the Evaluator runs the bounded all-drafts policy pass: its findings retain Evaluator actor provenance, while Planner checks and user/advisor responses retain their own real actors and evidence classes.

## 7. F9 handoff evidence

F9 is a machine-readable JSON evidence family stored under `reviews/.harness/handoffs/`, normally as `M1_to_M2.json`, `M2_to_M3.json`, `M3_to_M4.json`, `M4_to_M5.json`, and a terminal M5 packet. F9 is evidence, not lifecycle state. `reviews/phase_state.json` binds each packet path and SHA-256.

Under effective `audited`, acceptance requires the exact packet and successor
begin consumes it. Under effective `derived`, acceptance is authoritative with
the exact handoff representation `{status: not_applicable, packet_path: null,
packet_sha256: null}`. `accept --emit-f9` may publish the same exact F9 bytes as
audited mode, but the packet remains optional, non-gating, and non-consumed;
successor begin validates it without rewriting its ready state or emitting a
`handoff_consumed` event.

An F9 packet records `artifact_family: F9`, contract version, project, lineage, from/to milestone, predecessor packet binding except at M1, deliverable path/hash/bytes/role, inputs consumed, decisions frozen, feedback dispositions, open debts, next-milestone instructions, the exact draft and scholarly policy bindings, and approval authority/evidence/time. Adjacent packets use `to_milestone: M2 | M3 | M4 | M5`; the terminal M5 packet uses `to_milestone: null`. A qualified scholarly evaluation is necessary but never supplies user approval. A packet cannot become `ready` without separate current approval evidence. Only effective `audited` gives the ready packet consumption authority; effective `derived` never does.

An F9 Markdown rendering, if produced, is a `derived_view`; it carries its source binding, generation time, and a do-not-edit marker.

## 8. Reopening and downstream staleness

Reopening appends history; it never edits an old approval into a new one.

1. The Planner appends `milestone_reopened` with actor, reason, scope, lineage, and old/current content bindings.
2. Each dependent handoff becomes `needs_revalidation` and receives a `downstream_stale` event.
3. The Planner records an impact adjudication for each downstream milestone: `revalidated`, `reopened`, or `superseded` by an explicit lineage.
4. Revalidation records new evidence and bindings; reopening records required work; supersession preserves the displaced lineage.
5. M5 cannot be accepted while any upstream dependency is stale.

Changed accepted bytes trigger the same stale-dependency behavior. The validator reports the block; it does not auto-demote phase state. Planner and the authorized user decide the phase and milestone recovery path.

Milestone event types are:

`milestone_started | deliverable_recorded | feedback_recorded | feedback_adjudicated | milestone_accepted | handoff_ready | handoff_consumed | milestone_reopened | downstream_stale | downstream_revalidated | milestone_superseded | authorized_override | migration_hold | migration_accepted`

The append-only `milestone_framework.events[]` array is part of the sole `phase_state.json` authority. Every event carries `sequence` (unique, contiguous from 1), a full RFC3339 UTC `timestamp` (`YYYY-MM-DDTHH:MM:SS[.fraction]Z` only), `event_type`, `milestone`, `lineage_id`, `actor`, `authority`, non-empty `reason`, optional exact-byte `evidence_path` + `evidence_sha256`, `caused_by_sequence`, and typed `bindings[]` (`artifact`, `feedback`, `approval`, `handoff_packet`, `override`, `migration`, `previous_content`, or `current_content`). `deliverable_recorded` is an auxiliary Planner event appended in the same guarded transaction that adds or replaces the current primary-lineage deliverable before acceptance; it binds that artifact's exact path and SHA-256 and grants neither status nor approval. `downstream_stale` causally references an earlier reopened milestone on the same lineage and strictly upstream of the affected milestone; `downstream_revalidated` references the stale event for the same affected milestone and lineage, preserving that root chain. Other events carry `caused_by_sequence: null`. Every status (`not_started`, `in_progress`, `not_applicable`, `accepted`, `reopened`, `superseded`) and every handoff projection is justified by its latest relevant event; an old acceptance or handoff cannot justify reset work without a later reopen/start/override/migration event. Acceptance binds the current deliverable and approval evidence; each feedback-recorded/adjudicated event binds the current feedback source path/hash; handoff events bind the current F9 hash. Full historical replay beyond current-state justification remains a future migration/replay extension; validators already enforce ordering, subject-aware causality, current-state consistency, and exact-byte bindings.

## 9. Gate outcomes and exit semantics

Applicability and readiness are separate. Validators and compatible preflight gates use:

| Outcome | Meaning | Exit |
|---|---|---:|
| `READY` | A native applicable contract satisfies every predicate. | 0 |
| `LEGACY_READY` | An explicit approved migration record grandfathers already-crossed work; warnings remain visible. | 0 |
| `NOT_APPLICABLE` | A higher-authority record supplies reason, scope, and substitute evidence. | 0 |
| `MISCONFIGURED` | State is missing, contradictory, stale, malformed, or only implicitly absent. | 4 |

Usage errors exit 1. I/O or parse failures exit 2. Authorized N/A and no-op outcomes succeed; absence never silently means legacy or N/A.

## 10. Native projects

A project bootstrapped under this contract uses `mode: native`, contract `1.1.0`, and explicit handoff policy (default `derived`); it declares exactly M1-M5, begins M1 as `in_progress`, and begins M2-M5 as `not_started`. File presence never implies acceptance. Each milestone becomes accepted only after its deliverable, feedback gate, adjudication, approval, exact-byte binding, and policy-correct handoff representation satisfy this protocol.

The native milestone namespace lives only inside `reviews/phase_state.json`. Project `AGENTS.md`, status notes, and lifecycle summaries link to the authority or a generated view; they do not maintain parallel status.

## 11. Legacy migration

Legacy migration is discovery-first and dry-run-first. It inventories ledgers, candidate deliverables, controls, feedback, exports, paths, and lineages; emits an evidence matrix and proposed graph without writing canonical state; and creates a HOLD for every ambiguity. A user-authorized adjudication selects the primary lineage, applicability, completed-through boundary, and disposition of each hold before any atomic canonical write.

Migration preserves raw artifacts and archives the prior ledger with exact hashes. It must be idempotent and produce a rollback manifest. Divergent archive/live candidates never auto-merge. Missing historical feedback is recorded as `not captured under prior contract`; feedback, approvals, lineage, or completion are never fabricated. Already-crossed work receives `LEGACY_READY` only through an explicit approved migration record.

### 11.1 Policy-only 1.0.0 to derived migration

An existing valid `1.0.0` ledger changes to explicit derived policy only through
`scripts/migrate_lab_iteration_derived_handoff.py` and migration ID
`lab-iteration-derived-handoff-v1`. The operator supplies a separate immutable,
exact-preimage authority receipt. The required sequence is `dry-run`, `apply`,
and read-only `verify`; `rollback` restores the original ledger bytes exactly.
There is no validator, bootstrap, or ordinary-laboratory rewrite path.

The transaction may change only `/milestone_framework/contract_version` from
`1.0.0` to `1.1.0` and add `/milestone_framework/handoff_policy: derived`.
Historical ready/consumed F9 records, events, approvals, active milestone state,
assignment state, artifacts, promotion surfaces, protected bytes, and final
deliverables remain byte-identical. Dry-run and verify write nothing. Apply and
rollback use an exclusive no-TTL claim, exact concurrent-hash rechecks, and an
atomic ledger replacement as their last authoritative-state write.

The five closed schemas are
`schemas/milestone_handoff_policy_migration_{authority,claim,receipt,rollback_manifest,rollback_receipt}.schema.json`.
To avoid an impossible reciprocal hash cycle, `apply.json` hash-binds the
rollback manifest; the manifest contains only a closed project-relative locator
back to `apply.json`. A rollback receipt independently hash-binds both current
files. Recovery never guesses from TTL or PID reuse and requires the exact
`inspected-migration-state-and-receipts` acknowledgement plus a proven-dead
same-host owner and recognized ledger bytes.

## 12. Derived views

Human lifecycle summaries are deterministic views of `reviews/phase_state.json` and any policy-correct F9 evidence. A lifecycle view records `generated: true`, `derived_from`, `source_sha256`, and `generated_at`; its body begins `DO NOT EDIT: generated lifecycle view` and labels declared and effective handoff policy. A `1.0.0` compatibility view explicitly reports `implicit audited`; a `1.1.0` view reports its explicit declared policy.

Derived views never satisfy deliverable slots, own lifecycle status, or override source state. Source-hash mismatch is drift and requires regeneration after the authoritative state is corrected.

## 13. Exemplar governance

Projects do not self-declare exemplar status. The sole credential authority is the project-external package registry at `references/milestone_exemplars.json`; its empty state is exactly `{"schema_version":"1.0.0","entries":[]}`. Absence from the registry is normal and does not affect ordinary `READY` or `LEGACY_READY` outcomes. A project-local claim never substitutes for registration, even when the project has a valid registry entry.

Each registry entry is strict and closed. It records one canonical absolute `project_path`, one allowed `exemplar_class`, explicit `approval_authority`, approval evidence path and SHA-256, current package `validator_version`, class-appropriate `validator_outcome`, a role-typed array of validator/evidence path and SHA-256 bindings, a strict RFC3339 UTC `registered_at`, and the current `reviews/phase_state.json` SHA-256. Duplicate registrations for one canonical identity and registrations that assign both classes to one identity are invalid. Evidence roles are an exact class-specific set: clean registration admits only milestone validator, phase validator, lifecycle view, release gate, and independent replay; legacy registration admits only milestone validator, phase validator, migration report, migration commit, migration manifest, rollback verification, and migration approval. Missing, duplicate, cross-class, or unknown roles invalidate the entry even when their bytes and hashes are internally consistent.

All registered evidence paths are project-relative, contained, current-byte hash-bound, regular non-reparse files. The registry and each evidence object are acquired as one stable binary snapshot: raw path components are checked before opening; the open descriptor is bound to the pre-open path identity; descriptor size, identity, and modification time must remain stable through the read; and the path must still name the same non-reparse file afterward. Registry and evidence UTF-8/JSON failures or path replacement races produce controlled `MF-EXEMPLAR` findings. A custom registry may be injected by the validator CLI for maintenance and tests and may live outside the project or package, but the explicit registry path is subject to the same regular-file, non-reparse, stable-snapshot rule.

`clean_lifecycle_exemplar` requires `mode: native`; accepted, approved, dependency-current M1-M5 records; the effective-policy-correct M1-M5 handoff representations (consumed/ready exact packets for `audited`, or canonical `not_applicable` with any optional packets valid and non-consumed for `derived`); current milestone- and phase-validator evidence; a generated lifecycle view whose source hash is the current ledger; a full release-gate pass; and an independent replay. `legacy_migration_exemplar` requires `mode: legacy`, an approved migration boundary, current milestone and phase validation with `LEGACY_READY`, and separately hash-bound migration approval, report, commit, manifest, and rollback-verification evidence. The migration boundary authority must itself be on the permitted exemplar/migration authority ladder. The migration report must record an approved adjudication by that boundary authority, and the migration approval evidence must explicitly say `APPROVED` and name the same authority. Rehashing a chain attributed to `nobody` or another unrecognized actor cannot grant the class.

These are two separate approval layers. The migration-boundary authority approves the historical migration; the registry `approval_authority` approves granting exemplar status. Both must be independently permitted and supported by their own evidence, but they need not be the same actor. Registration records these decisions; it does not collapse them, rewrite ledger outcome, or alter historical provenance.

Self-declaration detection is deliberately bounded. The validator inspects the machine ledger and only the declared project authority/status surfaces `AGENTS.md` and `reviews/lifecycle_state.md`. It recognizes exact lifecycle credential keys, exact credential headings, Markdown status fields or tables, and affirmative project-is/remains/serves-as/designated-as/registered-as declarations for `portfolio exemplar`, `reference implementation`, `clean_lifecycle_exemplar`, or `legacy_migration_exemplar`. Sentence subjects are limited to `this project`, `the project`, the canonical project-root name, and the ledger `manuscript_id`; identity matching is case-insensitive. Arbitrary bare subjects, arbitrary ledger scalars, negations, questions, and analytical mentions do not count. It does not scan manuscripts or arbitrary reviews, where ordinary disciplinary uses of “exemplar” or “reference implementation” are not lifecycle claims.

For a registered clean exemplar, the lifecycle-view evidence hash is also the exact-byte derived-view binding. Any manual edit therefore emits both `MF-EXEMPLAR` and `MF-DERIVED`; editing or deleting the local claim cannot create or restore the external credential.

## 14. Validator codes

| Code | Predicate | Failure |
|---|---|---|
| `MF-STRUCTURE` | M1-M5 records contain the required contract fields. | BLOCKER |
| `MF-ROLE` | M4/M5 primary deliverables are manuscripts, never plans, checklists, or gates. | BLOCKER |
| `MF-CANON` | Canonical paths exist and obey project canonical-source rules. | BLOCKER |
| `MF-BINDING` | Accepted artifact and packet hashes and byte counts match current bytes. | BLOCKER |
| `AMC-SCHOLARLY-EVALUATION-MISSING` | An applicable recorded milestone carries no scholarly-evaluation binding. | BLOCKER |
| `AMC-SCHOLARLY-EVALUATION-STALE` | C6 evidence, its authority chain, artifact binding, or a transitive dependency is stale or unqualified. | BLOCKER |
| `MF-HANDOFF` | Successor work satisfies the effective handoff policy: audited consumption, or derived accepted/current state with optional F9 validated but never consumed. | BLOCKER |
| `MF-FEEDBACK` | Feedback is typed, attributable, hash-bound, and blocking items are adjudicated. | BLOCKER |
| `MF-LINEAGE` | Active candidates have distinct lineages and exactly one primary lineage. | BLOCKER |
| `MF-REOPEN` | Drift or reopening creates append-only history and downstream staleness. | BLOCKER |
| `MF-PHASE` | M4/M5 state agrees with phase, MCR, G.4, and terminal conditions. | BLOCKER |
| `MF-POLICY` | Reader intent, resolved policy, and current-hash accessibility evidence form one chain. | BLOCKER |
| `MF-EXPORT` | A released export exists and binds the accepted manuscript. | BLOCKER |
| `MF-DERIVED` | Generated lifecycle views match the current ledger hash. | MAJOR |
| `MF-OVERRIDE` | N/A or waiver has authority, reason, scope, evidence, and an event. | BLOCKER |
| `MF-STATUS` | Maintained prose does not claim authority or contradict the ledger. | MAJOR |
| `MF-EXEMPLAR` | Exemplar registration satisfies class-specific external evidence. | BLOCKER |

Malformed but parseable state must produce controlled findings, never an uncaught exception.
