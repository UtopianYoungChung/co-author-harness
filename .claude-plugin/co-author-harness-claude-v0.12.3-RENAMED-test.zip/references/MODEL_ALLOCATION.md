# MODEL_ALLOCATION.md — Tier-Conditioned Model Dispatch

*Package reference, v0.7.3. Single source of truth for the per-tier × per-agent Claude-model mapping the Planner resolves at dispatch time. Binds the **role-to-capability** mapping to the **Lifecycle-Stage Ladder** — T1 Plan & Draft / T2 Review & Revise / T3 Iterate & Converge / T4 Finalize & Close — so that model capability tracks adversarial load rather than paragraph volume. Read this file before any invocation that spawns a subagent; the Planner reads it unconditionally at every dispatch. At v0.7.4 the tier identifiers will rename to **Ph1–Ph4**; model assignments are expected to carry forward unchanged.*

---

## 1. The intentionality behind tier-conditioned dispatch

The four-agent pipeline was designed with a separation-of-duties guarantee: the Generator is the only writer, the Evaluator never writes prose, the Reflector audits both, and the Planner dispatches but never mutates the manuscript. That contract is about *role* — what an agent is allowed to do. What it did not, until v0.7.3, say anything about, is *capability* — what model a given role should be backed by, at a given lifecycle stage, to produce the adversarial pressure the pipeline is supposed to exert. v0.7.3 closes that gap by making model capability a tier-conditioned dispatch decision that the Planner resolves from this file.

The strategic-dependency framing is that the author depends on each agent for a specific softgoal — the Evaluator for *adversarial integrity*, the Generator for *fluent, constraint-honouring prose*, the Reflector for *lesson retention* and *grounding audit*, the Planner for *orchestration*. Two of those softgoals — adversarial integrity at T2/T3/T4, and lesson-retention at T4 close-out — are the slots where weak capability is the fatal failure mode, because an under-powered Evaluator or Reflector silently passes work that a stronger model would have flagged. Those slots are the non-negotiable floor below. Every other slot is sized for the work actually in scope at that tier, and the default disposition is to downshift to Sonnet 4.6 unless the slot is on the floor.

## 2. The allocation table

| Agent | T1 Plan & Draft | T2 Review & Revise | T3 Iterate & Converge | T4 Finalize & Close |
|---|---|---|---|---|
| **Planner** | Sonnet 4.6 | Sonnet 4.6 | Sonnet 4.6 | Sonnet 4.6 ↓ |
| **Evaluator** | — *(dormant)* | **Opus 4.7** ★ | **Opus 4.7** ★ | **Opus 4.7** ★ |
| **Generator** | Sonnet 4.6 ↓ | Sonnet 4.6 | Sonnet 4.6 | Sonnet 4.6 ↓ |
| **Reflector** | Haiku 4.5 *(lightweight)* | Haiku 4.5 *(lightweight)* | Haiku 4.5 *(lightweight)* | **Opus 4.7** *(full)* ★ |

**Legend.** ★ = non-negotiable Opus 4.7 floor (see §3). ↓ = downshift from the naive default of "match model to role-seniority"; rationale in §4. *(dormant)* = tier-conditioned non-engagement per `AGENT_ORCHESTRATION.md §3.0`. *(lightweight)* / *(full)* = Reflector dispatch mode per the two-mode split retained from v0.7.0.

The model strings the Planner passes to the Agent tool's `model` parameter are `claude-opus-4-7`, `claude-sonnet-4-6`, and `claude-haiku-4-5-20251001` respectively. The Planner does not accept per-agent overrides in `agents/*.md` frontmatter; dispatch is resolved exclusively from this file.

## 3. The non-negotiable Opus 4.7 floor

Four slots are on the floor and will not downshift without a package-level protocol change:

- **Evaluator at T2.** T2 is the first tier at which the Evaluator engages, and the pass is a full local-scope review — `REVIEW_ORCHESTRATION.md` Steps 1–3 plus the integrated checklist plus the SAFEGUARD subset (Checks 1, 4, 5, 8 in advisory mode with BLOCKER-CANDIDATE tagging). The cost of a missed finding at T2 compounds through every T3 iteration; adversarial capability here is load-bearing.
- **Evaluator at T3.** T3 is the unbounded iterate-until-stable stage; the Evaluator runs the full seven-step judgment pass, the complete SAFEGUARD layer (all eight checks), and the Coupling E.2 graph-grounding overlay at Step 0.2 on every iteration. Convergence is defined as two consecutive rounds clearing the 0.03 threshold on the declared `convergence_metric`; false convergence from a weak Evaluator is the single largest integrity hazard in the pipeline.
- **Evaluator at T4.** T4 Finalize & Close is a strict superset of T3 with external verifiers REQUIRED and G.4 sign-off mandatory. The cost of a missed blocker at T4 is submission of a defective manuscript; there is no downstream tier to catch it.
- **Reflector-full at T4.** The T4 close-out Reflector runs all five phases plus the audit blocks (T3 convergence audit, `[T3-STALE]` / MCR volatility audit, migrated confirmation-failed historical audit, Phase 2g accessibility-recurrence audit at v0.7.2, Phase 2f tier-row contract audit, the Grounding-Protocol self-audit at Phase 2.6). Plugin-update proposals filed here shape the next version of the package; weak lesson extraction at this slot would propagate to every subsequent project. Lightweight Reflector at T1/T2/T3 is bounded to Phases 1, 2.5, 2.6, 2f, 3 and is explicitly a memory-only integrity probe — the capability requirement there is about a narrow grounding audit, not synthesis, which is why Haiku 4.5 is acceptable on a 30-day pilot (see §5).

## 4. The downshift rationale

Three slots downshift from the naive baseline of "match model to role-seniority":

- **Generator at T1.** T1 drafting is bounded-scope prose production against the Planner-issued revision plan under the declared voice register. The Generator's authority here is full, but the adversarial pressure — the part of the pipeline that actually benefits from Opus-class capability — comes from the Evaluator at T2. Sonnet 4.6 produces constraint-honouring prose at T1 drafting with observable fluency; the capability gap to Opus 4.7 is not detectable in the T1 deliverable. Downshift accepted.
- **Generator at T4.** T4 Generator is fix-only-no-new-prose — the contract explicitly forbids new drafting at T4. The work is surgical application of Evaluator-surfaced blockers, not authorship. Sonnet 4.6 executes bounded edits against a detailed findings report reliably; the Opus 4.7 uplift is not earned at this slot.
- **Planner at T4.** The T4 Planner runs admission gating (MCR verification), dispatch, and artefact assembly. The adversarial work at T4 is concentrated in the Evaluator and Reflector-full slots; the Planner's job is orchestration and ledger discipline. Sonnet 4.6 is sufficient.

Planner at T1/T2/T3 remains Sonnet 4.6 by default because the Planner's work at those stages — classification, revision-plan authorship, dispatch, user-facing checkpoint presentation — is bounded-scope structured output against this file and the orchestration references. The Planner's strength at being a good Planner is not improved by Opus capability at these stages; it is improved by having *this file* to resolve dispatch against.

## 5. Named hazards

Two hazards are called out explicitly and are the subject of ongoing audit.

**Hazard H-MA-1 (capability inversion).** A round in which a Sonnet-backed Evaluator confronts Opus-backed Generator output would invert the intended adversarial pressure — the reviewer would be weaker than the writer, and the pipeline's integrity guarantee would degrade from "adversarial" to "cosmetic". This configuration is prohibited. No package-level or project-level directive may produce a round in which the Evaluator's model capability is below the Generator's on the family ordering `{Haiku 4.5} ≺ {Sonnet 4.6} ≺ {Opus 4.7}`. The Planner checks the resolved allocation at dispatch and refuses the round with `E-MA-CAPABILITY-INVERSION` if the invariant would be violated; the Reflector re-audits the resolved allocation at Phase 2f and files a finding if the Planner allowed an inversion through.

**Hazard H-MA-2 (Reflector-floor pilot).** Haiku 4.5 at the Reflector-lightweight slot is on a **30-day pilot** from the v0.7.3 release date. The capability question under test is whether Haiku 4.5 can reliably execute the grounding-audit sub-phase (Phase 2.5/2.6 read-through of revision diffs against the Grounding Protocol) and the tier-row contract audit (Phase 2f) without false-negatives. If the pilot surfaces a false-negative pattern — a grounding violation that Haiku 4.5 passed and Opus 4.7 would have caught — the Reflector itself will propose `A6-reflector-floor-uplift` to the Planner's three-filter gatekeeper, and the allocation will lift to Sonnet 4.6 at the lightweight slot. Pilot telemetry is kept in `reviews/reflection_report.md` under a new `model_dispatch_audit` block the Reflector writes on every lightweight run.

## 6. Absent-means-inherit migration semantics

Projects that predate v0.7.3 have no `model_dispatch` field in `reviews/tier_state.json` and no entries in their `reviews/classification.md` that speak to model selection. Such projects inherit the allocation in §2 unconditionally at first Planner invocation under v0.7.3; no migration script is required, and no user-visible ledger field is added. If a project wants to opt out of a specific slot's default — for example, to force Opus 4.7 at the Generator-T3 slot during a contested revision round — the opt-out is declared in `research_notes/directives.md` as a project directive, which sits at precedence level 4 in `CLAUDE.md §5` and outranks this file (precedence level 5, package component). The directive syntax is:

```
D-NN: Model dispatch override — Generator-T3 := Opus 4.7
Justification: [project-specific reason, one paragraph]
Scope: [per-round | per-section | for duration of project]
```

The Planner reads the directive at dispatch, logs the override to `reviews/tier_state.json` in the `log[].notes` field as `model_override:{agent}-{tier}:={model}`, and proceeds. The Reflector Phase 2f audit verifies that every override was justified by an active directive; orphan overrides are flagged as `R-Refl-MA-3` findings.

## 7. Reflector Phase 2f audit extension

Phase 2f of the Reflector-full run (tier-row contract audit) is extended at v0.7.3 to audit model-selection consistency across the round. The three invariants checked are:

- **I-MA-1 (allocation concordance).** Every dispatch in the round's `tier_state.json log` array resolves to an `actor` and `trigger` consistent with the agent's allocation in §2 for the row's tier. If a row shows `actor: evaluator` at a T1 row, the audit flags `E-MA-DORMANT-ACTOR-ENGAGED` — the Evaluator is dormant at T1 and should not have written a row.
- **I-MA-2 (capability non-inversion).** No round in the log shows the Evaluator downshifted below the Generator on the family ordering `{Haiku 4.5} ≺ {Sonnet 4.6} ≺ {Opus 4.7}`. Violations are `R-Refl-MA-1` with BLOCKER severity.
- **I-MA-3 (override provenance).** Every `model_override:...` notes-field entry corresponds to an active directive in `research_notes/directives.md`. Orphan overrides are `R-Refl-MA-3` with MAJOR severity.

Findings from Phase 2f model-selection audit are appended to the same `reviews/reflection_report.md` block the pilot telemetry lives in (§5), under a `model_dispatch_audit` heading, and feed the three-filter gatekeeper for any `A6-reflector-floor-uplift` or related plugin-update proposals.

## 8. Deprecation and forward compatibility

Opus 4.6 is deprecating and is not in the allocation. Any project directive that hard-codes `claude-opus-4-6` will be rejected at dispatch with `E-MA-DEPRECATED-MODEL`; the Planner will prompt the user to choose between Opus 4.7 (capability-equivalent forward) and Sonnet 4.6 (cost-efficient alternative). The model strings the Planner passes are documented in §2; these strings are the contract surface, and any future model family release (e.g., a hypothetical Opus 5.0) will require a v0.7.5 or later package version with updated allocation and updated capability-ordering in §5.

At v0.7.4 the tier identifiers in §2 will rename T1 → Ph1, T2 → Ph2, T3 → Ph3, T4 → Ph4 in concert with the broader Tier → Phase rename. Model assignments carry forward unchanged under that rename; the ledger migration script at `scripts/migrate_v073_to_v074.py` (to be authored as part of v0.7.4) rewrites identifiers only.

---

*Normative status.* This file is at precedence level 5 (package component) per `CLAUDE.md §5`. Project directives (level 4) override this file; venue and advisor instructions (levels 2 and 3) override both; the user's explicit instruction in the current conversation (level 1) is supreme. `GROUNDING_PROTOCOL.md` sits outside the ladder and is absolute — no model dispatch decision licenses a grounding violation.

